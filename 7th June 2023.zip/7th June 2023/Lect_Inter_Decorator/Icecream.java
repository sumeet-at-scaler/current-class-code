package FairWork.Lect_Inter_Decorator;

public interface Icecream {
    int getCost();
    String getDesc();
}
