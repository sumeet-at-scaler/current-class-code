package FairWork.Lect_Inter_Observor;

public class OrderDetails {
    int orderId;
    String address;
    String pno;
    String email;
}
