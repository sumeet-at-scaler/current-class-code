package FairWork.Lect_Inter_Observor;

public interface CreateOrderObservor {
    void newOrderCreated(OrderDetails od);
}
