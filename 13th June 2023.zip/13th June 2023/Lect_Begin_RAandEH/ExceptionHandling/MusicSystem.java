package FairWork.Lect_Begin_RAandEH.ExceptionHandling;

public interface MusicSystem {
    void play();
    void pause();
}
