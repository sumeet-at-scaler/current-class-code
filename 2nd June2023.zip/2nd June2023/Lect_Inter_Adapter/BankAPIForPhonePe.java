package FairWork.Lect_Inter_Adapter;

public interface BankAPIForPhonePe {
    int checkBal(int ano);
    void addMoney(int ano, int money);
    void subMoney(int ano, int money);
}
