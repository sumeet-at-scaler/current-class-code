package FairWork.Lect_Inter_Factory.Common;

public interface Query {
    void execute();
}
