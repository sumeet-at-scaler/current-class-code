package FairWork.Lect_Inter_Factory.Common;

public class MySQLQuery implements Query {
    public void execute(){
        System.out.println("logic to execute my sql query");
    }
}
