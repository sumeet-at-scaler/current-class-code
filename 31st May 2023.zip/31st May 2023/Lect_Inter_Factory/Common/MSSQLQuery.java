package FairWork.Lect_Inter_Factory.Common;

public class MSSQLQuery implements Query {
    public void execute(){
        System.out.println("logic to execute ms sql query");
    }
}
