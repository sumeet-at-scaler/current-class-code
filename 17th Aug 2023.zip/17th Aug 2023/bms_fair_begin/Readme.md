Major Annotations

0. Getter, Setter => Lombok
1. Entity
2. MappedSuperClass
3. Id
4. GeneratedValue(strategy = GenerationType.IDENTITY)
5. relation
    5.1 OnetoMany (mappedBy = ?)
    5.2 ManyToOne
6. enums

-> All relationships have been expressed twice and used mappedBy on one side to prevent duplicacy