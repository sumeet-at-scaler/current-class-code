package FairWork.Lect_Begin_Streams.FI;

public class DemoImplementation implements DemoInterface{
    @Override
    public void fun() {
        System.out.println("demo logic");
    }
}
