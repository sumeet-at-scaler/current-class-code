package FairWork.Lect_Begin_Streams.FI;

@FunctionalInterface
public interface DemoInterface {
    void fun();
    default void fun2(){

    }
}
