package FairWork.Lecture_Inter_SOLID2.LSP_Solution_Demo;

public class Square extends Rectangle {
    Square(int side){
        super(side, side);
    }
}
