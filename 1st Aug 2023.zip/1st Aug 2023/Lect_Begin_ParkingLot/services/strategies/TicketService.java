package FairWork.Lect_Begin_ParkingLot.services.strategies;

public class TicketService {
}
