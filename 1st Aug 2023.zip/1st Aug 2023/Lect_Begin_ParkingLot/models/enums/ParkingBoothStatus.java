package FairWork.Lect_Begin_ParkingLot.models.enums;

public enum ParkingBoothStatus {
    AVAILABLE,
    OCCUPIED,
    UNDER_MAINTENANCE
}
