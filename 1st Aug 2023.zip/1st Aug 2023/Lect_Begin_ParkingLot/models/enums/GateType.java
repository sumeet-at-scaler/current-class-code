package FairWork.Lect_Begin_ParkingLot.models.enums;

public enum GateType {
    ENTRY,
    EXIT
}
