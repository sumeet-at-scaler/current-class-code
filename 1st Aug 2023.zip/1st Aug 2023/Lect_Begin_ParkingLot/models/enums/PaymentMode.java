package FairWork.Lect_Begin_ParkingLot.models.enums;

public enum PaymentMode {
    CASH,
    ONLINE
}
