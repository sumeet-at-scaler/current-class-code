package FairWork.Lect_Begin_ParkingLot.models.enums;

public enum PaymentStatus {
    SUCCESS,
    FAILURE,
    IN_PROGRESS,
    CANCELLED
}
