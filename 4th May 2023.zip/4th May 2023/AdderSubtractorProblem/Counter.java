package FairWork.Lect11_Threads.AdderSubtractorProblem;

public class Counter {
    int val = 0;
}
