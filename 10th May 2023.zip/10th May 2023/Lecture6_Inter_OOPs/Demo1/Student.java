package FairWork.Lecture6_Inter_OOPs.Demo1;

public class Student {
    final int age = 10;
    final int height;

    Student(){
//        age = 20;
        height = 20;
    }
}
