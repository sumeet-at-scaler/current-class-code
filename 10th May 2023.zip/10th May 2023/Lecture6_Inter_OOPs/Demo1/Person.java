package FairWork.Lecture6_Inter_OOPs.Demo1;

public class Person {
    int age;
    String name;
    Person(int age, String name){
        this.age = age;
        this.name = name;
    }
}
