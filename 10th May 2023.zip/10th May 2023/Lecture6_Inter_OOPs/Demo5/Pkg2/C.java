package FairWork.Lecture6_Inter_OOPs.Demo5.Pkg2;

import FairWork.Lecture6_Inter_OOPs.Demo5.Pkg1.A;

public class C extends A {
    @Override
    public void fun() {
//        d1 = 10;
//        d2 = 20;
        d3 = 30;
        d4 = 40;
    }
}
