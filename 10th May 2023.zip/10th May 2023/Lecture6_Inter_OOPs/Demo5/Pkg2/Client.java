package FairWork.Lecture6_Inter_OOPs.Demo5.Pkg2;

import FairWork.Lecture6_Inter_OOPs.Demo5.Pkg1.A;

public class Client {
    public static void main(String[] args) {
        A obj = new A();
//        obj.d1 = 10;
//        obj.d2 = 20;
//        obj.d3 = 30;

        obj.d4 = 40;
    }
}

