package FairWork.Lecture6_Inter_OOPs.Demo5.Pkg1;

public class A {
    private int d1;
    int d2;
    protected int d3;
    public int d4;

    public void fun(){
        d1 = 10;
        d2 = 20;
        d3 = 30;
        d4 = 40;
    }
}
