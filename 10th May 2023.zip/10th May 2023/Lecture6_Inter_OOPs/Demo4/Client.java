package FairWork.Lecture6_Inter_OOPs.Demo4;

public class Client {
    public static void main(String[] args) {
//        C obj = new C();

        C obj = new C(10, 20, 30);
    }
}
