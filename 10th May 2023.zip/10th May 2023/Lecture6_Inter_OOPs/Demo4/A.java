package FairWork.Lecture6_Inter_OOPs.Demo4;

public class A {
    int d1;

//    A(){
//        System.out.println("I am in A");
//    }

    A(int data1){
        this.d1 = data1;
    }
}
