package FairWork.Lecture6_Inter_OOPs.Demo4;

public class B extends A {
    int d2;

//    B(){
//        System.out.println("I am in B");
//    }

    B(int data1, int data2){
        super(data1);
        this.d2 = data2;
    }
}
