package FairWork.Lecture6_Inter_OOPs.Demo3;

public class B extends A {
    void fun1(){
        System.out.println("f1 in B");
    }

//    void fun(){
//        System.out.println("f in A");
//    }

    void fun(int x, int y){
        // an example of overloading and not overriding
    }
}
