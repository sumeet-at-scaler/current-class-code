package FairWork.Lecture6_Inter_OOPs.Demo6;

public class B extends A {
    void fun1(){
        System.out.println("B's fun1");
    }

    static void fun2(){
        System.out.println("B's fun2");
    }

//    static void fun3(){
//        System.out.println("B's fun3");
//    }

//    void fun4(){
//
//    }

}
