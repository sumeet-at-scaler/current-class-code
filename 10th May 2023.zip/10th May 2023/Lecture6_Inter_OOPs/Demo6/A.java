package FairWork.Lecture6_Inter_OOPs.Demo6;

public class A {
    void fun1(){
        System.out.println("A's fun1");
    }

    static void fun2(){
        System.out.println("A's fun2");
    }

//    void fun3(){
//        System.out.println("A's fun3");
//    }

//    static void fun4(){
//        System.out.println("A's fun4");
//    }
}
