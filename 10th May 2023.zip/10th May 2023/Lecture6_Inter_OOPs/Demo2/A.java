package FairWork.Lecture6_Inter_OOPs.Demo2;

public final class A {
    int d = 10;
    void fun(){
        System.out.println("f of A");
    }
}
