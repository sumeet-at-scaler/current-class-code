package FairWork.Lecture6_Inter_OOPs.Demo2;

//public class B extends A {
public class B {
}
