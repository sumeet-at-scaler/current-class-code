package FairWork.Lect_Inter_ParkingLot.dtos;

public enum ResponseStatus {
    FAILURE,
    SUCCESS
}
