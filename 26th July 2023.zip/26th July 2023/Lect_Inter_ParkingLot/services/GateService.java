package FairWork.Lect_Inter_ParkingLot.services;

import FairWork.Lect_Inter_ParkingLot.models.Gate;

public class GateService {

    public Gate getGateById(Long gateId){
        // make a hit to gateRepo to get the gateid
        return null;
    }
}
