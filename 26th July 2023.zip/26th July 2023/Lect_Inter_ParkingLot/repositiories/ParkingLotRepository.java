package FairWork.Lect_Inter_ParkingLot.repositiories;

import FairWork.Lect_Inter_ParkingLot.models.ParkingLot;
import FairWork.Lect_Inter_ParkingLot.models.Ticket;

import java.util.HashMap;

public class ParkingLotRepository {

    public ParkingLot getParkingLotByGateId(Long gateId){
        return null;
    }
}
