package FairWork.Lect_Inter_ParkingLot.repositiories;

import FairWork.Lect_Inter_ParkingLot.models.ParkingSlot;
import FairWork.Lect_Inter_ParkingLot.models.Ticket;

import java.util.HashMap;
import java.util.List;

public class ParkingSlotRepository {

    public List<ParkingSlot> getAllParkingSlotsByParkingLotId(Long parkingLotId){
        return null;
    }
    // PL: PS
    // 1: m
    // 1: 1
    // 1: m
    // query
    // SELECT * FROM ParkingSlots WHERE parkingLotId = ??
}
