package FairWork.Lect_Inter_ParkingLot.models.enums;

public enum VehicleType {
    SMALL,
    MEDIUM,
    HEAVY
}
