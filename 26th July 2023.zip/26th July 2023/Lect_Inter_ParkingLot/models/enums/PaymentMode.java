package FairWork.Lect_Inter_ParkingLot.models.enums;

public enum PaymentMode {
    CASH,
    ONLINE
}
