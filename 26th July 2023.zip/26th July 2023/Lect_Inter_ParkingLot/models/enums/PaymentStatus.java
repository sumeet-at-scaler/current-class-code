package FairWork.Lect_Inter_ParkingLot.models.enums;

public enum PaymentStatus {
    IN_PROGRESS,
    FAILED,
    SUCCESS,
    CANCELLED
}
