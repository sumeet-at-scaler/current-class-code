package FairWork.Lect_Inter_ParkingLot.models.enums;

public enum ParkingSpotStatus {
    AVAILABLE,
    OCCUPIED,
    UNDER_MAINTENANCE
}
