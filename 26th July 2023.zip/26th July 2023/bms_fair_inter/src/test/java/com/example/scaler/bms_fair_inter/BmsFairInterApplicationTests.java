package com.example.scaler.bms_fair_inter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmsFairInterApplicationTests {

    @Test
    void contextLoads() {
    }

}
