package com.example.scaler.bms_fair_inter.models.enums;

public enum PaymentProvider {
    STRIPE,
    RAZORPAY,
    GPAY,
    AMAZONPAY
}
