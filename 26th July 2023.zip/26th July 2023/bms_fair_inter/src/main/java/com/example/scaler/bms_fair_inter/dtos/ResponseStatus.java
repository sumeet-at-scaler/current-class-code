package com.example.scaler.bms_fair_inter.dtos;

public enum ResponseStatus {
    FAILURE,
    SUCCESS
}
