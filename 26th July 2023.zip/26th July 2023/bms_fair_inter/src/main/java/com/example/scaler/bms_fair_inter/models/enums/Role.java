package com.example.scaler.bms_fair_inter.models.enums;

public enum Role {
    ADMIN,
    OWNER,
    CUSTOMER
}
