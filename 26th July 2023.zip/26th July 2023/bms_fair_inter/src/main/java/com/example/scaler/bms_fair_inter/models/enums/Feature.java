package com.example.scaler.bms_fair_inter.models.enums;

public enum Feature {
    TWOD,
    THREED,
    DOLBY,
    ATMOS
}
