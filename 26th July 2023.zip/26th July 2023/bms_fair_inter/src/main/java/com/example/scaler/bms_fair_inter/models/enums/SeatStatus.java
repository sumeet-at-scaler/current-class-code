package com.example.scaler.bms_fair_inter.models.enums;

public enum SeatStatus {
    UNDER_MAINTENANCE,
    AVAILABLE,
    LOCKED,
    BOOKED,
}
