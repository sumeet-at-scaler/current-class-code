package com.example.scaler.bms_fair_inter.models.enums;

public enum SeatType {
    SILVER,
    GOLD,
    PLATINUM
}
