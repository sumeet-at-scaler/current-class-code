package com.example.scaler.bms_fair_inter.models.enums;

public enum PaymentStatus {
    INPROGRESS,
    SUCCESS,
    FAILURE,
    CANCELLED
}
