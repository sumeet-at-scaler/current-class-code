package FairWork.Lect_Begin_RAEH.EH.demo1;

import java.io.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        System.out.println("hello");
        System.out.println("shello");

        Scanner scn = new Scanner(System.in);
        int n = scn.nextInt();

        System.out.println("bye");
        System.out.println("waye");
    }
}
