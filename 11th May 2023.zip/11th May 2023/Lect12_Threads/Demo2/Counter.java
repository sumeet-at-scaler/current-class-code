package FairWork.Lect12_Threads.Demo2;

public class Counter {
    int val = 0;
}
