package FairWork.Lect12_Threads.Demo1;

public class Counter {
    int val = 0;
}
