package FairWork.Lect12_Threads.Demo4;

import java.util.concurrent.atomic.AtomicInteger;

public class Counter {
    AtomicInteger val = new AtomicInteger(0);
}
