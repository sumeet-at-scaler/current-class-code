package FairWork.Lect_Inter_FW;

public class Point {
    int x;
    int y;
    int z;
}
