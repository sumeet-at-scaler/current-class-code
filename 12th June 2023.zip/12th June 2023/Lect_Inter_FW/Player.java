package FairWork.Lect_Inter_FW;

public class Player {
    int currHealth;
    int ranking;
    Point currPos;
    int score;
    PlayerFW fw;
}
