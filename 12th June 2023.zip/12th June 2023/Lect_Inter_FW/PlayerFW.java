package FairWork.Lect_Inter_FW;

import java.awt.*;

public class PlayerFW {
    int offencePower;
    int iniHealth;
    Image avatar;

    PlayerFW(int offencePower, int iniHealth, Image avatar){
        this.offencePower = offencePower;
        this.iniHealth = iniHealth;
        this.avatar = avatar;
    }
}
