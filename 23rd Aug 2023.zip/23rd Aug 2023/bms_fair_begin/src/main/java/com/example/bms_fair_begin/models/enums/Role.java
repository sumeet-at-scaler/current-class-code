package com.example.bms_fair_begin.models.enums;

public enum Role {
    Admin,
    Owner,
    Customer
}
