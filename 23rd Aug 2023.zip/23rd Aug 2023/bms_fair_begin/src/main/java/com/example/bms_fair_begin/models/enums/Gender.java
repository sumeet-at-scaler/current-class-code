package com.example.bms_fair_begin.models.enums;

public enum Gender {
    Male,
    Female
}
