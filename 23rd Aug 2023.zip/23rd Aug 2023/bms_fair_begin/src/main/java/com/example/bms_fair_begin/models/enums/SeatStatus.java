package com.example.bms_fair_begin.models.enums;

public enum SeatStatus {
    Under_Maintenance,
    Available,
    Locked,
    Booked
}
