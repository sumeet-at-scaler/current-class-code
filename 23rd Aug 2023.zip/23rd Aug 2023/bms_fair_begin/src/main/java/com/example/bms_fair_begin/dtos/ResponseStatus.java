package com.example.bms_fair_begin.dtos;

public enum ResponseStatus {
    SUCCESS,
    FAILURE
}
