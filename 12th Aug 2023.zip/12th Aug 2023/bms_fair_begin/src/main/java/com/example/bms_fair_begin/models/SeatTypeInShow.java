package com.example.bms_fair_begin.models;

public class SeatTypeInShow extends BaseModel {
}
