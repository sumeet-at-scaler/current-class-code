package com.example.bms_fair_begin.models.enums;

public enum PaymentStatus {
    IN_PROGRESS,
    FAILED,
    CANCELLED,
    SUCCESS
}
