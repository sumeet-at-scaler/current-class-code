package com.example.bms_fair_begin.models.enums;

public enum PaymentMode {
    UPI,
    Credit,
    Debit,
    NetBanking
}
