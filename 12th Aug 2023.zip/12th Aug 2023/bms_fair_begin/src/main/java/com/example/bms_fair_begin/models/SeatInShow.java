package com.example.bms_fair_begin.models;

public class SeatInShow extends BaseModel {
}
