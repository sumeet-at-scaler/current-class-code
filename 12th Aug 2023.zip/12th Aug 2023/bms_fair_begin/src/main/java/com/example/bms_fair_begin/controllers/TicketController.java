package com.example.bms_fair_begin.controllers;

public class TicketController {
    // generate a ticket => select the seats
    // 1. retrieve
    // 2. check if available
    // 3.1 no => exception
    // 3.2 yes => lock the seats
}
