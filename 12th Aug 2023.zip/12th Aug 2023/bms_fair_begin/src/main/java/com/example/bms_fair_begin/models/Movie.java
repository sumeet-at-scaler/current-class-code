package com.example.bms_fair_begin.models;

public class Movie extends BaseModel {
}
