package com.example.bms_fair_begin.models;

public class Show extends BaseModel {
}
