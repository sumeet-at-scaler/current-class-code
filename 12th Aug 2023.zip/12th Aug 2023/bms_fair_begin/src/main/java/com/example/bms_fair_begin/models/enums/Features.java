package com.example.bms_fair_begin.models.enums;

public enum Features {
    TwoD,
    ThreeD,
    IMAX,
    Surround_Sound,
    Dolby,
    Atmos
}
