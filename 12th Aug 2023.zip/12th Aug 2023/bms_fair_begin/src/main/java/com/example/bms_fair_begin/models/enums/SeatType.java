package com.example.bms_fair_begin.models.enums;

public enum SeatType {
    SILVER,
    GOLD,
    PLATINUM
}
