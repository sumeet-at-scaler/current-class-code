package com.example.bms_fair_begin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmsFairBeginApplicationTests {

    @Test
    void contextLoads() {
    }

}
