package FairWork.Lecture8_Inter_OOPs.DigressionOnAM;

public class Client {
    public static void main(String[] args) {
        B obj = new B();
        System.out.println(obj.d2);
        System.out.println(obj.d4);
        obj.fun();
    }
}
