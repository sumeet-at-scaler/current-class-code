package FairWork.Lecture8_Inter_OOPs.DigressionOnAM;

public class B extends A {
    private int d3 = 30;
    public int d4 = 40;

    void fun(){
        System.out.println(d2);
        System.out.println(d3);
        System.out.println(d4);
        fun1();
    }
}
