package FairWork.Lecture8_Inter_OOPs.DigressionOnAM;

public class A {
    private int d1 = 10;
    public int d2 = 20;

    void fun1(){
        System.out.println(d1);
    }
}
