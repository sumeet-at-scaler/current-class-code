package FairWork.Lect_Inter_PrototypeAndRegistry;

public interface Prototype<T> {
    T clone();
}
