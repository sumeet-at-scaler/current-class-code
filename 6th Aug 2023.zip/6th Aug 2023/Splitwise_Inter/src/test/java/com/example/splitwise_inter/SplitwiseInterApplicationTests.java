package com.example.splitwise_inter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SplitwiseInterApplicationTests {

    @Test
    void contextLoads() {
    }

}
