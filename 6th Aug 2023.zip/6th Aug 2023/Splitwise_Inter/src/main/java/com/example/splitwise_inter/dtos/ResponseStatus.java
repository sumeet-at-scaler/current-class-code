package com.example.splitwise_inter.dtos;

public enum ResponseStatus {
    FAILURE,
    SUCCESS
}
