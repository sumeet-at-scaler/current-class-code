package FairWork.Lecture5_Inter_OOPs.Demo1;

public class B extends A {
    int d2;
    void fun2(){
        System.out.println("f2 of B");
    }

    void fun1(){
        System.out.println("f1 of B");
    }
}
