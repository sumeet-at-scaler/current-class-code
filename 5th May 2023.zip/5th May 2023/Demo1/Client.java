package FairWork.Lecture5_Inter_OOPs.Demo1;

public class Client {
    public static void main(String[] args) {
        B obj = new B();
        obj.d1 = 10;
        obj.fun1();

        obj.d2 = 20;
        obj.fun2();
    }
}
