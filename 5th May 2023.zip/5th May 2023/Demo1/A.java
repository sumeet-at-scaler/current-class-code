package FairWork.Lecture5_Inter_OOPs.Demo1;

public class A {
    int d1;
    void fun1(){
        System.out.println("f1 of A");
    }
}
