package FairWork.Lecture4_Inter_OOPs.Demo1;

public class Student {
    int age;
    String name;
    static String schoolName;
}
