package FairWork.Lecture4_Inter_OOPs.Demo3;

public class Client {
    public static void main(String[] args) {
        final int x;
        int y = 20;

        x = 100;
//        x++;
//        x = 23;

        System.out.println(x);
    }
}
