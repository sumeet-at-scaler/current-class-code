package FairWork.Lecture4_Inter_OOPs.Demo3;

public class DemoClass {
    final int x = 10;
    final int y;

    DemoClass(){
        y = 100;
    }
}
