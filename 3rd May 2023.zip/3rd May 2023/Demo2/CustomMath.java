package FairWork.Lecture4_Inter_OOPs.Demo2;

public class CustomMath {
    static int abs(int val){
        if(val < 0){
            val = val * -1;
        }

        return val;
    }
}
