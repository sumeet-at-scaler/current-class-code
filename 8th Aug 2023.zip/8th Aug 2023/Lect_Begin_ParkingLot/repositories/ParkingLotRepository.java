package FairWork.Lect_Begin_ParkingLot.repositories;

import FairWork.Lect_Begin_ParkingLot.models.Gate;
import FairWork.Lect_Begin_ParkingLot.models.ParkingLot;

import java.util.Optional;

// empty for students to finish
public class ParkingLotRepository {
    public ParkingLot fetchByGateId(Long gateId){
        return null;
    }

}
