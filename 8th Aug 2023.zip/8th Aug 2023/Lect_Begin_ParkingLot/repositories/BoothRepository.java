package FairWork.Lect_Begin_ParkingLot.repositories;

import FairWork.Lect_Begin_ParkingLot.models.Booth;

import java.util.List;

// empty for students to finish
public class BoothRepository {

    public List<Booth> fetchAllBoothsByParkingLot(Long parkingLotId){
        return null;
    }
}
