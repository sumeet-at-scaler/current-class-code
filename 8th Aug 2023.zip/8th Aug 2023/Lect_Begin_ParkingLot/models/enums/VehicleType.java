package FairWork.Lect_Begin_ParkingLot.models.enums;

public enum VehicleType {
    LIGHT,
    MEDIUM,
    HEAVY
}
