package FairWork.Lect_Begin_ParkingLot.dtos;

public enum ResponseStatus {
    SUCCESS,
    FAILURE
}
