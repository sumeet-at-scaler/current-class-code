package FairWork.Lecture_Inter_DIP;

public interface Flyable {
    void fly();
}
