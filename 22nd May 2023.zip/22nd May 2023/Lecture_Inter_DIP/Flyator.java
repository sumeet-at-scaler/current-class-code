package FairWork.Lecture_Inter_DIP;

public interface Flyator {
    void makeFly();
}
