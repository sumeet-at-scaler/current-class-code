package FairWork.Lecture_Inter_DIP;

public class SlowFlyator implements Flyator {

    @Override
    public void makeFly() {
        System.out.println("Logic for flying slow");
    }
}
