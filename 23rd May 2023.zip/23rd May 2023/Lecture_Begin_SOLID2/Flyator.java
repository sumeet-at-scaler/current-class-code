package FairWork.Lecture_Begin_SOLID2;

public interface Flyator {
    void flightAlgo();
}
