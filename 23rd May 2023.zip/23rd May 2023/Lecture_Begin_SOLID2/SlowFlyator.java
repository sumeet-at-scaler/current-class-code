package FairWork.Lecture_Begin_SOLID2;

public class SlowFlyator implements Flyator {
    @Override
    public void flightAlgo() {
        System.out.println("logic of slow flight");
    }
}
